let cards = document.querySelector(".container");

fetch('https://fakestoreapi.com/products')
.then(response => response.json())
.then(data => {
    
    data.forEach(element => {
        
         let comentEl = document.createElement("p");
         let elName = document.createElement("p")
         let newTextEl = document.createElement("h2");
        let elBox = document.createElement("div");
        let elImg = document.createElement("img");
        let elBtn = document.createElement("button");
        
        
        elImg.src = element.image;
        newTextEl.innerHTML = "Price: " + element.price;
        comentEl.innerHTML = "Discount: " + element.description.split("").splice(1, 70).join("") + "...";
        elName.innerHTML = "name: " + element.title;
        cards.appendChild(elBox);
        elBox.innerHTML = `<button class="delete-button" data-target-id="${element.id}"></button>`
        elBox.appendChild(elImg);
        elBox.appendChild(newTextEl);
        elBox.appendChild(comentEl);
        elBox.appendChild(elName);
        
        elImg.className = "adversiting";
        elBox.className = "box-cards";
        elName.className = "card-text";
        comentEl.className = "card-text-two"
        console.log(element);

        
        elBtn.addEventListener("click", (evt) => {
            if(confirm(evt.target.hasAttribute(data-target-id))){
                let elDelId = evt.target.dataset.targetId
                fetch(`https://fakestoreapi.com/products${elDelId}`) , {
                    method: "delete"

                }
                .then(del => console.log(del.json()))
            }
            
        })
        
    });
})