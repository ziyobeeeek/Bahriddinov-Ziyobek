// ulanishi
let elForm = document.querySelector(".form");
let elInput = document.querySelector(".input");
let elSearchBtn = document.querySelector(".site__search");
let elResaultBox = document.querySelector(".resoult") 
let commitRes = document.querySelector(".resoult-about");
let ReadingEl = document.querySelector(".resoult-title");
let elExample = document.querySelector(".exaple");
let elAudio = document.querySelector(".audio");

elForm.addEventListener('submit', (evt) => {
    evt.preventDefault();
    
     fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${elInput.value}`)
     .then(response => response.json())
     .then(data => {
        data.forEach(resaultEl => {
          
            commitRes.innerHTML = resaultEl.meanings[0].definitions[0].definition;
            
            ReadingEl.innerHTML =  resaultEl.word + " - " + resaultEl.phonetics[1].text.split('').slice(1, -1).join('');
            
            elAudio.setAttribute("controls", "")
            elAudio.src = element.phonetics[0].audio;
            console.log(resaultEl);
            
          });       
     })                         
})